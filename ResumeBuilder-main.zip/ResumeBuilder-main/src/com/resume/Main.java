package com.resume;

public class Main {
    public static void main(String[] args) {
        new CV();
    }
}
